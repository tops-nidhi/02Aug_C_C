// for clear the  values 
function clr()
{
    document.getElementById("result").value="";
} 
// display input values 
function display(v)
{
    document.getElementById("result").value+=v;
}

//remove single values  

function clr1()
{
    //alert('hi');
    // var x=document.getElementById("result").value;
    // alert(x);
    // document.getElementById("result").value.slice(0,-1)=x;
    
    document.getElementById("result").value.slice(0,-1)="x";
    // alert(x);
    // document.getElementById("result").value.slice(0,-1)=x;
}

// function clr1(){
//     var val = document.frm.result.value.slice(0, -1);
//     document.frm.result.value=val;
//     //alert(val);
    
// };

// result calculate here
function finalresult()
{
    var x=document.getElementById("result").value;
    var y=document.getElementById("result").value;
    x=eval(y);
    document.getElementById("result").value=x;
}
